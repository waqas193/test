<?php

	
	define('AllowedCountry','DK');
 
	define('YouTubeVideId' ,'ve7p-qref-vhu8-bacz');


?>